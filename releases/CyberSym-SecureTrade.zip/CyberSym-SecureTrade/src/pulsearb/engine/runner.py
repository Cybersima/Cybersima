from __future__ import annotations

import asyncio
import time
from pathlib import Path
from collections import deque

from pulsearb.branding import PRODUCT
from pulsearb.config import SPOT_VENUES, AppConfig
from pulsearb.engine.arbitrage import detect_auto_cross, detect_cross_venue, detect_triangles, discover_triangles
from pulsearb.engine.book import MarketBook
from pulsearb.engine.broker import Broker, LiveBinanceBroker, LiveRouter, PaperBroker
from pulsearb.engine.coinbase_live import LiveCoinbaseBroker
from pulsearb.engine.desk import KIND_LABELS, TradeDesk
from pulsearb.engine.report import ProfitLedger
from pulsearb.engine.risk import RiskManager
from pulsearb.feeds.binance import BinanceFeed
from pulsearb.feeds.bitstamp import BitstampFeed
from pulsearb.feeds.coinbase import CoinbaseFeed
from pulsearb.feeds.gemini import GeminiFeed
from pulsearb.feeds.kraken import KrakenFeed
from pulsearb.feeds.simulator import SimulatorFeed
from pulsearb.feeds.yahoo import YahooFeed
from pulsearb.models import EngineStats, Fill, Opportunity
from pulsearb.symbols import canonical_from_pair


class Engine:
    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.book = MarketBook()
        self.stats = EngineStats(started_at=time.time())
        self.opportunities: deque[Opportunity] = deque(maxlen=80)
        self.fills: deque[Fill] = deque(maxlen=80)
        self.seen: set[str] = set()
        self.invested: set[str] = set()
        self.by_id: dict[str, Opportunity] = {}
        self.listeners: set[asyncio.Queue] = set()
        min_notional = float(config.risk.get("min_notional_usdt", 1))
        default_size = max(min_notional, min(5.0, config.live_notional()))
        self.desk = TradeDesk(
            notional=default_size,
            max_notional=float(config.risk.get("max_notional_usdt", 250)),
            live_max=float(config.risk.get("live_max_notional_usdt", 25)),
            min_notional=min_notional,
            live=config.live_enabled(),
        )
        self._fee_map = config.fee_map()
        self._slippage = float(config.fees.get("extra_slippage_bps", 2))
        live = config.live_enabled()
        self.risk = RiskManager(
            max_notional_usdt=config.live_notional(),
            min_notional_usdt=min_notional,
            max_open_orders=int(config.risk.get("max_open_orders", 8 if live else 4)),
            daily_loss_limit_usdt=float(config.risk.get("daily_loss_limit_usdt", 100)),
            cooldown_seconds=float(
                config.risk.get("live_cooldown_seconds", 2) if live else config.risk.get("cooldown_seconds", 8)
            ),
            live_budget_usdt=float(config.risk.get("live_budget_usdt", config.live_notional())) if live else 0.0,
        )
        self.paper = PaperBroker(self.risk)
        self.broker: Broker = self.paper
        self.report = ProfitLedger(Path.cwd() / "data" / "CyberSym-SecureTrade-profit-report.csv")
        if config.live_enabled():
            coinbase_broker = None
            binance_broker = None
            creds = config.coinbase_credentials()
            if creds:
                key_name, secret = creds
                coinbase_cfg = config.markets.get("coinbase") or {}
                coinbase_broker = LiveCoinbaseBroker(
                    risk=self.risk,
                    api_key=key_name,
                    api_secret=secret,
                    paper_fallback=self.paper,
                    rest_url=str(coinbase_cfg.get("brokerage_url") or "https://api.coinbase.com"),
                )
            if config.binance_live_ready():
                binance = config.markets.get("binance") or {}
                rest = binance.get("testnet_rest_url" if config.env.binance_testnet else "rest_url")
                binance_broker = LiveBinanceBroker(
                    risk=self.risk,
                    api_key=config.env.binance_api_key,
                    api_secret=config.env.binance_api_secret,
                    rest_url=str(rest),
                    paper_fallback=self.paper,
                )
            self.broker = LiveRouter(self.paper, coinbase=coinbase_broker, binance=binance_broker)
        self.triangles_by_venue = {
            venue: discover_triangles(config.symbols(venue))
            for venue in SPOT_VENUES
            if config.symbols(venue)
        }
        self._lock = asyncio.Lock()

    def subscribe(self) -> asyncio.Queue:
        queue: asyncio.Queue = asyncio.Queue(maxsize=8)
        self.listeners.add(queue)
        return queue

    def unsubscribe(self, queue: asyncio.Queue) -> None:
        self.listeners.discard(queue)

    def snapshot(self) -> dict:
        quotes = sorted(self.book.snapshot(), key=lambda q: (q.venue, q.native_symbol))
        live = self.config.live_enabled()
        live_pnl = float(getattr(self.broker, "live_pnl", 0.0)) if live else 0.0
        venues = "+".join(getattr(self.broker, "live_venues", None) or self.config.live_venue_names())
        execution = f"live {venues}".strip() if live else "paper"
        balances = getattr(self.broker, "balances", {}) if live else {}
        return {
            "stats": {
                **self.stats.to_dict(),
                "paper_pnl": round(self.paper.pnl + live_pnl, 4),
                "live_pnl": round(live_pnl, 4),
                "killed": self.risk.killed,
                "execution": execution,
                "uptime_s": round(time.time() - self.stats.started_at, 1),
                "triangles": sum(len(items) for items in self.triangles_by_venue.values()),
                "report_rows": self.report.total_rows,
                "report_path": str(self.report.csv_path) if self.report.csv_path else "",
                "balances": {str(k): round(float(v), 8) for k, v in (balances or {}).items() if float(v) > 0},
                "live_note": (
                    "LIVE Coinbase: real market orders for Coinbase-only triangles. "
                    "Each tap is your desk size. Session budget is the $25 cap. "
                    "Cross-venue stays paper. Kill switch stops new orders."
                    if live
                    else ""
                ),
                "live_notional": self.desk.notional if live else self.desk.notional,
            },
            "desk": self.desk_view(),
            "quotes": [q.to_dict() for q in quotes],
            "opportunities": [self._opp_view(o) for o in list(self.opportunities)[:40]],
            "fills": [f.to_dict() for f in list(self.fills)[:40]],
        }

    async def broadcast(self) -> None:
        data = self.snapshot()
        dead = []
        for queue in list(self.listeners):
            if queue.full():
                try:
                    queue.get_nowait()
                except asyncio.QueueEmpty:
                    pass
            try:
                queue.put_nowait(data)
            except asyncio.QueueFull:
                dead.append(queue)
        for queue in dead:
            self.unsubscribe(queue)

    def _opp_view(self, opp: Opportunity) -> dict:
        data = opp.to_dict()
        pending = (
            opp.executable
            and opp.id not in self.invested
            and self.desk.matches(opp)
            and not self.risk.killed
        )
        data.update(
            {
                "kind_label": KIND_LABELS.get(opp.kind.value, opp.kind.value),
                "expected_pnl": round(self.desk.notional * opp.net_edge_bps / 10_000, 4),
                "notional": self.desk.notional,
                "pending": pending,
                "investable": pending and not self.desk.auto_invest,
                "chosen": self.desk.matches(opp),
            }
        )
        return data

    def desk_view(self) -> dict:
        data = self.desk.to_dict()
        left = self.risk.remaining_budget()
        data.update(
            {
                "budget": self.risk.live_budget_usdt if self.config.live_enabled() else None,
                "budget_left": left,
                "taps_left": self.risk.taps_left(self.desk.notional),
            }
        )
        return data

    def apply_desk(self, payload: dict) -> dict:
        self.desk.live = self.config.live_enabled()
        self.desk.apply(payload)
        return self.desk_view()

    async def invest(self, opportunity_id: str) -> dict:
        opp = self.by_id.get(opportunity_id)
        if opp is None:
            return {"ok": False, "error": "That trade is no longer on the board."}
        if not opp.executable:
            return {"ok": False, "error": "That row is watch-only (delayed data)."}
        if not self.desk.matches(opp):
            return {"ok": False, "error": "Turn on that coin or exchange in Choose what to invest."}
        if opportunity_id in self.invested:
            return {"ok": False, "error": "You already took this trade."}
        fills = await self._take(opp)
        await self.broadcast()
        return {"ok": True, "fills": [fill.to_dict() for fill in fills], "desk": self.desk_view()}

    async def _take(self, opp: Opportunity) -> list[Fill]:
        opp.notional = self.desk.notional
        fills = await self.broker.execute(opp)
        self.invested.add(opp.id)
        for fill in fills:
            self.fills.appendleft(fill)
            if fill.status == "blocked":
                self.stats.live_blocked += 1
        self.report.record_opportunity(
            opp,
            fills,
            paper=all(fill.paper for fill in fills) if fills else self.broker.paper,
            killed=self.risk.killed,
            fee_map=self._fee_map,
            slippage_bps=self._slippage,
        )
        return fills

    def _demo_instruments(self) -> list[tuple[str, str, bool]]:
        rows: list[tuple[str, str, bool]] = []
        for venue in SPOT_VENUES:
            if venue == "binance" and not self.config.env.enable_binance:
                continue
            for symbol in self.config.symbols(venue):
                try:
                    canon = canonical_from_pair(symbol)
                except ValueError:
                    continue
                rows.append((venue, canon, True))
        for row in self.config.yahoo_symbols:
            rows.append(("yahoo", row["canonical"], False))
        return rows

    async def run_feeds(self) -> None:
        tasks = []
        markets = self.config.markets
        settings = self.config.settings
        sim = settings.get("simulator") or {}
        demo_only = self.config.env.demo_only

        if sim.get("enabled", False) or demo_only:
            tasks.append(
                SimulatorFeed(
                    instruments=self._demo_instruments(),
                    inject_gaps=bool(sim.get("inject_gaps", True)),
                    gap_every_seconds=float(sim.get("gap_every_seconds", 18)),
                ).run(self.book, self.stats.feed_status)
            )
        if not demo_only:
            if self.config.venue_enabled("coinbase"):
                cfg = markets["coinbase"]
                tasks.append(
                    CoinbaseFeed(
                        symbols=self.config.symbols("coinbase"),
                        rest_url=str(cfg.get("rest_url")),
                        ws_url=str(cfg.get("ws_url")),
                        poll_seconds=float(cfg.get("poll_seconds") or settings.get("coinbase_poll_seconds", 1.0)),
                    ).run(self.book, self.stats.feed_status)
                )
            if self.config.venue_enabled("kraken"):
                cfg = markets["kraken"]
                tasks.append(
                    KrakenFeed(
                        symbols=self.config.symbols("kraken"),
                        rest_url=str(cfg.get("rest_url")),
                        poll_seconds=float(cfg.get("poll_seconds") or settings.get("kraken_poll_seconds", 1.0)),
                    ).run(self.book, self.stats.feed_status)
                )
            if self.config.venue_enabled("gemini"):
                cfg = markets["gemini"]
                tasks.append(
                    GeminiFeed(
                        symbols=self.config.symbols("gemini"),
                        rest_url=str(cfg.get("rest_url")),
                        poll_seconds=float(cfg.get("poll_seconds") or settings.get("gemini_poll_seconds", 1.0)),
                    ).run(self.book, self.stats.feed_status)
                )
            if self.config.venue_enabled("bitstamp"):
                cfg = markets["bitstamp"]
                tasks.append(
                    BitstampFeed(
                        symbols=self.config.symbols("bitstamp"),
                        rest_url=str(cfg.get("rest_url")),
                        poll_seconds=float(cfg.get("poll_seconds") or settings.get("bitstamp_poll_seconds", 1.0)),
                    ).run(self.book, self.stats.feed_status)
                )
            if self.config.venue_enabled("binance"):
                cfg = markets["binance"]
                rest = cfg.get("testnet_rest_url" if self.config.env.binance_testnet else "rest_url")
                ws = cfg.get("testnet_ws_url" if self.config.env.binance_testnet else "ws_url")
                tasks.append(
                    BinanceFeed(
                        symbols=self.config.binance_symbols,
                        rest_url=str(rest),
                        ws_url=str(ws),
                        rest_poll_seconds=float(settings.get("binance_rest_poll_seconds", 1.0)),
                    ).run(self.book, self.stats.feed_status)
                )
            if self.config.venue_enabled("yahoo"):
                cfg = markets["yahoo"]
                tasks.append(
                    YahooFeed(
                        symbols=self.config.yahoo_symbols,
                        poll_seconds=float(cfg.get("poll_seconds") or settings.get("yahoo_poll_seconds", 2.0)),
                    ).run(self.book, self.stats.feed_status)
                )
        if not tasks:
            raise RuntimeError("No market feeds enabled")
        await asyncio.gather(*tasks)

    async def run_scanner(self) -> None:
        interval = self.config.scan_interval_ms / 1000.0
        fee_map = self._fee_map
        extra = self._slippage
        min_alert = float(self.config.settings.get("min_edge_bps", 8))
        min_exec = float(self.config.settings.get("min_executable_edge_bps", 25))
        stale = float(self.config.risk.get("stale_quote_seconds", 8))
        while True:
            started = time.perf_counter()
            notional = self.desk.notional
            cross = detect_cross_venue(
                self.book,
                self.config.markets.get("cross_venue") or [],
                min_alert,
                fee_map,
                extra,
                notional,
            )
            auto = detect_auto_cross(
                self.book,
                self.config.usd_equivalents,
                min_alert,
                fee_map,
                extra,
                notional,
                stale_seconds=stale,
            )
            triangles: list[Opportunity] = []
            for venue, tri in self.triangles_by_venue.items():
                taker = fee_map.get(venue, 26)
                scan_venue = venue
                triangles.extend(
                    detect_triangles(
                        self.book,
                        tri,
                        min_exec,
                        taker,
                        extra,
                        notional,
                        venue=scan_venue,
                    )
                )
            # Demo quotes use real venue names, so the venue-scoped scan above is enough.
            fresh = [opp for opp in (*cross, *auto, *triangles) if opp.id not in self.seen]
            for opp in fresh:
                self.seen.add(opp.id)
                self.by_id[opp.id] = opp
                if len(self.by_id) > 2000:
                    self.by_id = {item.id: item for item in self.opportunities}
                self.opportunities.appendleft(opp)
                self.stats.opportunities += 1
                if (
                    opp.executable
                    and self.desk.auto_invest
                    and not self.desk.live
                    and not self.config.live_enabled()
                    and self.desk.matches(opp)
                    and not self.risk.killed
                ):
                    await self._take(opp)
                elif not opp.executable:
                    self.report.record_opportunity(
                        opp,
                        [],
                        paper=True,
                        killed=self.risk.killed,
                        fee_map=fee_map,
                        slippage_bps=extra,
                    )
            self.stats.scans += 1
            self.stats.quotes = self.book.size()
            self.stats.markets_live = self.book.live_count(stale)
            self.stats.last_scan_ms = (time.perf_counter() - started) * 1000
            await self.broadcast()
            await asyncio.sleep(interval)


async def run_engine(engine: Engine) -> None:
    coinbase = getattr(engine.broker, "coinbase", None)
    if coinbase is not None and hasattr(coinbase, "refresh_balances"):
        balances = await coinbase.refresh_balances()
        shown = ", ".join(
            f"{asset} {amount:.6g}" for asset, amount in list(balances.items())[:8]
        ) or "(empty)"
        print(f"{PRODUCT} Coinbase account: {shown}")
    await asyncio.gather(engine.run_feeds(), engine.run_scanner())
